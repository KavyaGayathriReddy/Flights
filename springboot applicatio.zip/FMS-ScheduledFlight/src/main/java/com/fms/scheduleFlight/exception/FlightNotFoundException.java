package com.fms.scheduleFlight.exception;

public class FlightNotFoundException extends Exception {
	
	public FlightNotFoundException(String s) {
		super(s);
	}

}

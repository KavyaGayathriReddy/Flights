package com.fms.scheduleFlight.entity;

public enum FlightStatus {

	NOT_SCHEDULED,
	SCHEDULED,
	DELAYED,
	CANCELLED,
	ARRIVED,
	DEPARTED
}

package com.fms.scheduleFlight.exception;

public class ScheduleNotFoundException extends Exception{
	
	public ScheduleNotFoundException(String s) {
		super(s);
	}

}

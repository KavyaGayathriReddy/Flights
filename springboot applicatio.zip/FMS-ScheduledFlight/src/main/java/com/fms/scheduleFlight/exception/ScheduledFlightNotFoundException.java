package com.fms.scheduleFlight.exception;

public class ScheduledFlightNotFoundException extends Exception{

	public ScheduledFlightNotFoundException(String s) {
		super(s);
	}
}

package com.fms.scheduleFlight.exception;

public class NoScheduleListFoundException extends Exception {
	
	public NoScheduleListFoundException(String s) {
		super(s);
	}

}

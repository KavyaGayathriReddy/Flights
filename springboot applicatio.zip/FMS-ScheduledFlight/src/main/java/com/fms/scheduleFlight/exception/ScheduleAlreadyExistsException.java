package com.fms.scheduleFlight.exception;

public class ScheduleAlreadyExistsException extends Exception{
	
	public ScheduleAlreadyExistsException(String s) {
		super(s);
	}

}

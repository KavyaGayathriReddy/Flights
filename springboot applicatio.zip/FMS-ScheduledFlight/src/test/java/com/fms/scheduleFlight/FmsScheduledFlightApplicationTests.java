package com.fms.scheduleFlight;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FmsScheduledFlightApplicationTests {	
	
	@Test
	void contextLoads() {
		assertNotNull(getClass());
	}

	
}
